
/*
----------------------------------------------------------------------------------------------------------
    Name:		PSK_CPT_189_01_SumDiffProd
    Author:		Patrick_Stephane_Keuagho
    Language:	Java
    Date:		2025-02-07
    Purpose:	The purpose of this program is to read two floating point numbers from the user and 
    prints their sum, difference, and product.
----------------------------------------------------------------------------------------------------------
    Change Log
----------------------------------------------------------------------------------------------------------
    Who		Date		Reason
    PSK		2025-02-07	Original Version of Code
----------------------------------------------------------------------------------------------------------
*/

import java.util.Scanner;

public class PSK_CPT_189_01_SumDiffProd {
    public static void main(String[] args) {
        Scanner scnMyKbd = new Scanner(System.in); // Create a scanner object to get keyboard input.

        // Prompt the user to enter the numbers.
        System.out.print("Please enter your first number: ");
        double intFirstNum = scnMyKbd.nextDouble();

        System.out.print("Please enter your second number: ");
        double intSecNum = scnMyKbd.nextDouble();

        // Calculate the Sum of the two numbers
        double summation = intFirstNum + intSecNum;

        // Calculate the Difference of the two numbers
        double difference = intFirstNum - intSecNum;

        // Calculate the Product of the two numbers
        double product = intFirstNum * intSecNum;

        System.out.printf("The sum of %.2f and %.2f is: %.2f%n", intFirstNum, intSecNum, summation); //Keep 2 decimal places
        System.out.printf("The difference of %.2f and %.2f is: %.2f%n",intFirstNum, intSecNum, difference); //Keep 2 decimal places
        System.out.printf("The product  of %.2f and %.2f is: %.2f%n",intFirstNum, intSecNum, product);  //Keep 2 decimal places

        scnMyKbd.close();



    }
}
